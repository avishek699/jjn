### React SIMP
React SIMP is a Web Apps bundled with amazing animation using pure css, some romantic quotes, and special message with React Baffle Animation. 
The purpose is to surprise your crush / girlfriend and make them happy xD . 

We can customize the special message, quotes list, special color, etc.

- 📝[Visit React SIMP](https://yudas1337.github.io/React-SIMP)

### Technologies :
<ul>
<li>Backend  : Node JS / Express JS</li>
<li>Frontend : <ul>
<li>React JS</li>
<li>Css, Bootstrap 4</li>
<li>Jquery</li>
<li>React Spectrum</li>
<li>React Baffle</li>
<li>React SnowStorm</li>
</ul>
<li>Database : Mongoose / Mongo Atlas</li>
</ul>

### Special Effect
We can customize the special message anything we wanted.

![1](special.gif)
